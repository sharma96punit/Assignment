package com.cg.services;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.cg.entities.Chat;
import com.cg.entities.ChatPostRequest;
import com.cg.entities.ChatServer;


public interface ChatLogService {
	

	public List<Chat> getAllChat(String userID);

	public ResponseEntity deleteChat(String userID,String messageId);
	
	public void deleteChatServer(String userID);

	public String createChat(String userID,ChatPostRequest chat);

}
