package com.cg.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import com.cg.entities.Chat;
import com.cg.entities.ChatPostRequest;

import java.util.UUID;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;


public class ChatLogServiceImpl implements ChatLogService{
	
	HashMap<String, List<Chat>> chatog=new HashMap<>();
	HashMap<String,Chat> chats=new HashMap<>();

	@Override
	public List<Chat> getAllChat(String userID) {
		// TODO Auto-generated method stub
		List<Chat> userchat=chatog.get(userID);
		if(userchat.size()-10<0)
		{
		return userchat;
		}
		else
		{
			List<Chat> usChat = new ArrayList<>();
	     for(int i=userchat.size()-1;i>=userchat.size()-10;i--)
	     {
	    	 usChat.add(userchat.get(i));
	     }
	     return usChat;
		}
	}

	@Override
	public ResponseEntity deleteChat(String userID, String messageId) {
		// TODO Auto-generated method stub
		boolean chatfound=false;
		try {
		for(Chat a:chatog.get(userID))
		{
			
			if(a.getMessageId().equals(messageId))
			{
				chats.remove(messageId);
				chatfound=true;
				List<Chat> userchat=chatog.get(userID);
				userchat.remove(a);
				chatog.put(userID, userchat);
				break;
			}
			
		}
		if(chatfound)
		{
			return ResponseEntity.status(HttpStatus.OK).body("Chat Deleted SuccessFully");
		}
		else
		{
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Message id not found");
		}
		}
		catch(Exception e )
		{
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Message id not found");
		}
		
	}

	@Override
	public void deleteChatServer(String userID) {
		// TODO Auto-generated method stub
		for(Chat a:chatog.get(userID))
		{
			chats.remove(a.getMessageId());
			
		}
		chatog.remove(userID);
	}


	@Override
	public String createChat(String userID, ChatPostRequest chat) {
		// TODO Auto-generated method stub
		String msgId=UUID.randomUUID().toString();
		Chat chatToSave=new Chat();
		chatToSave.setMessageId(msgId);
		chatToSave.setMessage(chat.getMessage());
		chatToSave.setSent(chat.isSent());
		chatToSave.setTimestamp(chat.getTimestamp());
		chats.put(chatToSave.getMessageId(), chatToSave);
		List<Chat> chatdone=chatog.get(userID);
		if(chatdone == null)
		{
			List<Chat> chatNew=new ArrayList<Chat>();;
			chatNew.add(chatToSave);
			chatog.put(userID, chatNew);
		}
		else
		{
			chatdone.add(chatToSave);
		chatog.put(userID,chatdone);
		}
		return "Message ID is="+msgId;
		
	}
	
	

}