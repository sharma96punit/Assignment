package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entities.Chat;
import com.cg.entities.ChatPostRequest;
import com.cg.services.ChatLogService;
import com.cg.services.ChatLogServiceImpl;

@RestController
public class ChatLogController {
	
	
	ChatLogService chatService=new ChatLogServiceImpl();
	
	public ChatLogController(ChatLogService chatService) {
		// TODO Auto-generated constructor stub
		this.chatService=chatService;
	}
	public ChatLogController() {
		// TODO Auto-generated constructor stub
	}
	
	@PostMapping(value="/chatlogs/{user}", consumes = {"application/json"})
	public String createChat(@PathVariable String user,@RequestBody ChatPostRequest chat)
	{
		return "Chat Created "+chatService.createChat(user,chat);
	}

	@GetMapping("/chatlogs/{user}")
	public List<Chat> getAll(@PathVariable String user){
		return chatService.getAllChat(user);
	}
	
	@DeleteMapping(value = "/chatlogs/{user}")
	public String deleteUserChats(@PathVariable String user)
	{
		chatService.deleteChatServer(user);
		return "UserLog Deleted";
	}
	
	@DeleteMapping(value = "/chatlogs/{user}/{message}")
	public ResponseEntity deleteChat(@PathVariable String user,@PathVariable String message)
	{
		return chatService.deleteChat(user,message);
	}
}
