package com.cg.entities;

public class ChatPostRequest {
	private String message;

	private long timestamp;

	private boolean isSent;
	
	public ChatPostRequest() {
		// TODO Auto-generated constructor stub
	}

	public ChatPostRequest(String message, long timestamp, boolean isSent) {
		super();
		this.message = message;
		this.timestamp = timestamp;
		this.isSent = isSent;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}

	public boolean isSent() {
		return isSent;
	}

	public void setSent(boolean isSent) {
		this.isSent = isSent;
	}
	

}