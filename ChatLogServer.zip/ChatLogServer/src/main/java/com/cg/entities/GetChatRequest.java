package com.cg.entities;

public class GetChatRequest {
	
	private int limit;
	private String messageId;
	public GetChatRequest() {
		// TODO Auto-generated constructor stub
	}
	public GetChatRequest(int limit, String messageId) {
		super();
		this.limit = limit;
		this.messageId = messageId;
	}
	public int getLimit() {
		return limit;
	}
	public void setLimit(int limit) {
		this.limit = limit;
	}
	public String getMessageId() {
		return messageId;
	}
	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}
	
}
