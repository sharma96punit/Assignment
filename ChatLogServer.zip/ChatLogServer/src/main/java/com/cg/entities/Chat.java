package com.cg.entities;

public class Chat {


	private String messageId;
	
	private String message;

	private long timestamp;

	private boolean isSent;

	public Chat() {
		// TODO Auto-generated constructor stub
	}

	public Chat(String messageId, String message, long timestamp, boolean isSent) {
		super();
		this.messageId = messageId;
		this.message = message;
		this.timestamp = timestamp;
		this.isSent = isSent;
	}

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}

	public boolean isSent() {
		return isSent;
	}

	public void setSent(boolean isSent) {
		this.isSent = isSent;
	}
	

}