package com.cg.entities;

import java.util.List;

public class ChatServer {

	private String userId;

	private List<Chat> chatLog;

	public ChatServer() {
		// TODO Auto-generated constructor stub
	}

	public ChatServer(String userId, List<Chat> chatLog) {
		super();
		this.userId = userId;
		this.chatLog = chatLog;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public List<Chat> getChatLog() {
		return chatLog;
	}

	public void setChatLog(List<Chat> chatLog) {
		this.chatLog = chatLog;
	}

}
